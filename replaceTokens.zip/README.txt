Instructions to use:
Copy the folder to any location
Give execute permission to replaceTokens.sh
Change the current directory to where the folder is copied and Test using the following command:
./replaceTokens.sh ./index.html ./test.properties ./output/index.html

A folder named output should get created with the expected index.html file.