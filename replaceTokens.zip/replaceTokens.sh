inFile="$1"
propFile="$2"
outFile="$3"
test -d "$outFile" || mkdir -p "${outFile%/*}" && cp "$inFile" "$outFile"
cat "$inFile" > "$outFile"
while IFS="=" read -r key value; do
	case "$key" in
	  '#'*) ;;
	  *)
		sed -i "s|\[\[${key}\]\]|${value}|g" "$outFile"
	esac
done < "$propFile"
